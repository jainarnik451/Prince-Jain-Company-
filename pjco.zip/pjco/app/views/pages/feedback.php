<?php
$firm = setting('firm_name');
partial('page_head', ['heading' => 'Feedback', 'eyebrow' => 'Your Opinion Matters',
    'lead' => 'Tell us about your experience or share a suggestion. Feedback is reviewed by the firm before anything is published.']);
$opts = ['' => 'Select (optional)'];
foreach (service_categories() as $c) { $opts[$c['label']] = $c['label']; }
$opts['Other'] = 'Other';
$curRating = (int)old_raw('rating', 0);
?>
<section class="section">
  <div class="container narrow">
    <?php if ($done): ?>
      <div class="card success-card" role="status">
        <span class="success-icon"><?= icon('check', 'icon', 32) ?></span>
        <h2>Thank you for your feedback</h2>
        <p>We appreciate you taking the time to share your thoughts. Your feedback has been received and will be reviewed by the firm.</p>
        <div class="btn-row"><a class="btn btn-primary" href="<?= e(url('')) ?>">Back to Home</a></div>
      </div>
    <?php else: ?>
      <form class="form card" method="post" action="<?= e(url('feedback')) ?>" novalidate data-form="feedback">
        <?= csrf_field() ?><?= spam_fields() ?>
        <h2>Share your feedback</h2>
        <p class="muted">Fields marked <span class="req">*</span> are required.</p>
        <div class="field-row">
          <?php partial('field', ['name' => 'name', 'label' => 'Full name', 'required' => true, 'maxlength' => 120, 'autocomplete' => 'name']); ?>
          <?php partial('field', ['name' => 'email', 'label' => 'Email address (optional)', 'type' => 'email', 'maxlength' => 190, 'autocomplete' => 'email', 'help' => 'Never published.']); ?>
        </div>
        <?php partial('field', ['name' => 'service', 'label' => 'Service used', 'type' => 'select', 'options' => $opts]); ?>
        <fieldset class="field rating-field<?= has_error('rating') ? ' has-error' : '' ?>">
          <legend>Rating <span class="req" aria-hidden="true">*</span></legend>
          <div class="star-input">
            <?php for ($i = 5; $i >= 1; $i--): ?>
              <input type="radio" id="rate-<?= $i ?>" name="rating" value="<?= $i ?>" <?= $curRating === $i ? 'checked' : '' ?>>
              <label for="rate-<?= $i ?>" title="<?= $i ?> star<?= $i > 1 ? 's' : '' ?>"><?= icon('star', 'icon', 30) ?><span class="sr-only"><?= $i ?> star<?= $i > 1 ? 's' : '' ?></span></label>
            <?php endfor; ?>
          </div>
          <?= field_error('rating') ?>
        </fieldset>
        <?php partial('field', ['name' => 'message', 'label' => 'Feedback / suggestions', 'type' => 'textarea', 'required' => true, 'maxlength' => 2000, 'rows' => 5]); ?>
        <label class="checkbox"><input type="checkbox" name="consent" value="1" <?= old_raw('consent') ? 'checked' : '' ?>>
          <span>I agree that my feedback and name may be published on this website after the firm reviews it. (Optional. Feedback without this permission is never published.)</span></label>
        <button class="btn btn-primary btn-lg" type="submit" data-loading="Sending…">Submit Feedback</button>
      </form>
    <?php endif; ?>
  </div>
</section>

<?php if ($reviews): ?>
<section class="section section-grey">
  <div class="container">
    <div class="section-head"><p class="eyebrow">Client Feedback</p><h2>What clients have shared</h2></div>
    <?php partial('reviews', ['reviews' => $reviews]); ?>
  </div>
</section>
<?php endif; ?>
