<?php
unset($_SESSION['_old'], $_SESSION['_errors']);
$firm = setting('firm_name');
$path = request_path();
$canonical = $canonical ?? abs_url($path);
$ogImg = !empty($og_image) ? $og_image : setting('seo_og_image', 'assets/img/og-default.jpg');
$noindex = !empty($noindex);
$fullTitle = $title ?? $firm;
$nav = [
    ['', 'Home'], ['about', 'About Us'], ['services', 'Services'], ['expertise', 'Expertise'],
    ['insights', 'Insights'], ['feedback', 'Feedback'], ['contact', 'Contact Us'],
];
$isActive = function (string $p) use ($path): bool {
    return $p === '' ? $path === '' : ($path === $p || str_starts_with($path, $p . '/'));
};
$wa = setting('whatsapp_1');
$waText = 'Hello ' . $firm . ', I would like to enquire about your services.';
?><!doctype html>
<html lang="en-IN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($fullTitle) ?></title>
<?php if (!empty($description)): ?><meta name="description" content="<?= e($description) ?>"><?php endif; ?>

<link rel="canonical" href="<?= e($canonical) ?>">
<?php if ($noindex): ?><meta name="robots" content="noindex, follow"><?php endif; ?>

<meta property="og:site_name" content="<?= e($firm) ?>">
<meta property="og:type" content="<?= e($og_type ?? 'website') ?>">
<meta property="og:title" content="<?= e($fullTitle) ?>">
<?php if (!empty($description)): ?><meta property="og:description" content="<?= e($description) ?>"><?php endif; ?>

<meta property="og:url" content="<?= e($canonical) ?>">
<meta property="og:image" content="<?= e(abs_url($ogImg)) ?>">
<meta property="og:locale" content="en_IN">
<meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="#0B2545">
<link rel="icon" href="<?= e(url('favicon.svg')) ?>" type="image/svg+xml">
<link rel="icon" href="<?= e(url('favicon-32.png')) ?>" sizes="32x32" type="image/png">
<link rel="apple-touch-icon" href="<?= e(url('apple-touch-icon.png')) ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&amp;family=Manrope:wght@500;600;700;800&amp;display=swap">
<link rel="stylesheet" href="<?= e(asset('assets/css/site.css')) ?>">
<?php if (!empty($jsonld)) { echo json_ld($jsonld), "\n"; } ?>
<script src="<?= e(asset('assets/js/site.js')) ?>" defer></script>
</head>
<body class="page-<?= e($path === '' ? 'home' : preg_replace('/[^a-z0-9]+/', '-', $path)) ?>">
<a class="skip-link" href="#main">Skip to content</a>

<header class="site-header" id="top">
  <div class="container header-inner">
    <?php partial('logo', ['class' => 'logo-header']); ?>
    <nav class="main-nav" id="main-nav" aria-label="Main navigation">
      <ul>
        <?php foreach ($nav as [$p, $label]): ?>
          <li><a href="<?= e(url($p)) ?>"<?= $isActive($p) ? ' aria-current="page"' : '' ?>><?= e($label) ?></a></li>
        <?php endforeach; ?>
      </ul>
      <a class="btn btn-primary nav-cta" href="<?= e(url('book-consultation')) ?>">Book a Consultation</a>
    </nav>
    <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="main-nav" aria-label="Open menu">
      <span class="icon-open"><?= icon('menu') ?></span><span class="icon-close"><?= icon('close') ?></span>
    </button>
  </div>
</header>

<main id="main">
<?php foreach (flashes() as $f): ?>
  <div class="container"><div class="alert alert-<?= e($f['type']) ?>" role="<?= $f['type'] === 'error' ? 'alert' : 'status' ?>"><?= e($f['msg']) ?></div></div>
<?php endforeach; ?>
<?= $content ?>
</main>

<?php partial('footer'); ?>

<div class="floating" aria-label="Quick actions">
  <a class="fab fab-top" href="#top" aria-label="Back to top" hidden><?= icon('up', 'icon', 20) ?></a>
  <a class="fab fab-call" href="<?= e(tel_link(setting('phone'))) ?>" aria-label="Call <?= e($firm) ?>"><?= icon('phone', 'icon', 22) ?></a>
  <a class="fab fab-wa" href="<?= e(wa_link($wa, $waText)) ?>" target="_blank" rel="noopener noreferrer" aria-label="Chat with us on WhatsApp"><?= icon('whatsapp', 'icon', 24) ?></a>
</div>
</body>
</html>
